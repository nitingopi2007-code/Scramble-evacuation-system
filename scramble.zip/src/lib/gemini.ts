import { GoogleGenAI, Type } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;

export const getGeminiAI = () => {
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not set");
  }
  return new GoogleGenAI({ apiKey });
};

export const SCRAMBLE_SYSTEM_PROMPT = `
You are the SCRAMBLE AI Co-pilot, a senior disaster response intelligence agent.
Your role is to assist responders in managing city-scale evacuations.

You have access to live data about zones and shelters.
When answering questions:
1. Be precise and serious.
2. Use data to back up your claims.
3. If asked to perform an action, use the available tools.
4. Provide evacuation instructions in multiple languages if requested.

Current City Context:
- The city is divided into zones (Z1-Z4).
- Shelters are designated as S1-S3.
- Hazard detection is based on Sentinel-1 SAR data.

Safety:
- Do not hallucinate data.
- Confirm critical actions.
`;

export const getEvacuationInstructions = async (zoneId: string, shelterId: string, language: string = "English") => {
  const ai = getGeminiAI();
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Generate evacuation instructions for Zone ${zoneId} heading to Shelter ${shelterId} in ${language}. Include:
    - Route priority
    - Estimated time of arrival
    - Critical hazards to avoid
    - Emergency contact info`,
    config: {
      systemInstruction: SCRAMBLE_SYSTEM_PROMPT,
    },
  });
  return response.text;
};
