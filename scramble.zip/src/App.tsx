import React, { useState } from 'react';
import { Homepage } from './components/Homepage';
import { Dashboard } from './components/Dashboard';
import { AICopilot } from './components/AICopilot';
import { HazardsPage } from './components/HazardsPage';
import { SettingsPage } from './components/SettingsPage';
import { AppProvider } from './AppContext';
import { LayoutGrid, Home, Shield, Settings, Menu, X } from 'lucide-react';

export default function App() {
  const [view, setView] = useState<'home' | 'dashboard' | 'hazards' | 'settings'>('home');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  return (
    <AppProvider>
      <div className="flex h-screen bg-black text-white font-sans overflow-hidden">
        {/* Sidebar Navigation */}
        <nav className={`bg-zinc-950 border-r border-zinc-800 flex flex-col transition-all duration-300 ${isSidebarOpen ? 'w-20' : 'w-0 overflow-hidden'}`}>
          <div className="p-6 flex justify-center">
            <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center font-bold text-black">S</div>
          </div>
          
          <div className="flex-1 flex flex-col items-center gap-8 pt-12">
            <NavIcon active={view === 'home'} onClick={() => setView('home')} icon={<Home size={24} />} label="Home" />
            <NavIcon active={view === 'dashboard'} onClick={() => setView('dashboard')} icon={<LayoutGrid size={24} />} label="Command" />
            <NavIcon active={view === 'hazards'} onClick={() => setView('hazards')} icon={<Shield size={24} />} label="Hazards" />
            <NavIcon active={view === 'settings'} onClick={() => setView('settings')} icon={<Settings size={24} />} label="Settings" />
          </div>

          <div className="p-6 flex justify-center">
             <button onClick={() => setIsSidebarOpen(false)} className="text-zinc-500 hover:text-white">
               <X size={20} />
             </button>
          </div>
        </nav>

        {!isSidebarOpen && (
          <button 
            onClick={() => setIsSidebarOpen(true)}
            className="fixed top-6 left-6 z-50 p-2 bg-zinc-900 border border-zinc-800 rounded-lg text-zinc-400 hover:text-white"
          >
            <Menu size={20} />
          </button>
        )}

        {/* Main Content Area */}
        <div className="flex-1 flex overflow-hidden">
          {view === 'home' && <Homepage />}
          {view === 'dashboard' && <Dashboard />}
          {view === 'hazards' && <HazardsPage />}
          {view === 'settings' && <SettingsPage />}
          
          {/* AI Co-pilot always present in Dashboard and Hazards, optional in Home */}
          {(view === 'dashboard' || view === 'hazards') && <AICopilot />}
        </div>
      </div>
    </AppProvider>
  );
}

const NavIcon = ({ active, icon, label, onClick }: { active: boolean, icon: React.ReactNode, label: string, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className={`group relative p-3 rounded-xl transition-all duration-300 ${active ? 'bg-emerald-500 text-black' : 'text-zinc-500 hover:bg-zinc-900 hover:text-white'}`}
  >
    {icon}
    <span className="absolute left-full ml-4 px-2 py-1 bg-zinc-900 text-white text-[10px] font-bold rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
      {label}
    </span>
  </button>
);
