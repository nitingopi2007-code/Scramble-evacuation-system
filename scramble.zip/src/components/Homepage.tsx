import React from 'react';
import { motion } from 'motion/react';
import { Shield, Activity, Map as MapIcon, Users, AlertTriangle } from 'lucide-react';
import { useApp } from '../AppContext';

export const Homepage: React.FC = () => {
  const { zones, shelters } = useApp();
  
  const activeZones = zones.filter(z => z.status === 'Active').length;
  const totalEvacuating = zones.reduce((acc, z) => acc + (z.status === 'Active' ? z.population : 0), 0);
  const openShelters = shelters.filter(s => s.status === 'Open').length;

  return (
    <div className="relative min-h-screen bg-[#050505] text-white overflow-hidden font-sans">
      {/* Background Animated Grid */}
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px]"></div>
      </div>

      {/* Hero Section */}
      <main className="relative z-10 container mx-auto px-6 pt-24 pb-12">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-mono uppercase tracking-widest flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              System Status: Operational
            </div>
          </div>

          <h1 className="text-7xl md:text-9xl font-bold tracking-tighter mb-8 leading-[0.85]">
            SCRAMBLE<span className="text-emerald-500">.</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-zinc-400 max-w-2xl mb-12 leading-relaxed">
            AI-powered civilian evacuation intelligence. From satellite detection to safety routing in under <span className="text-white font-semibold">3 minutes</span>.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <StatCard icon={<AlertTriangle className="text-amber-500" />} label="Active Zones" value={activeZones} />
            <StatCard icon={<Users className="text-blue-500" />} label="People Evacuating" value={totalEvacuating.toLocaleString()} />
            <StatCard icon={<Shield className="text-emerald-500" />} label="Open Shelters" value={openShelters} />
          </div>

          <div className="flex flex-wrap gap-4">
            <button className="px-8 py-4 bg-white text-black font-bold rounded-full hover:bg-emerald-500 hover:text-white transition-all duration-300 flex items-center gap-2">
              <Activity size={20} />
              Launch Command Center
            </button>
            <button className="px-8 py-4 bg-zinc-900 text-white font-bold rounded-full border border-zinc-800 hover:border-zinc-700 transition-all duration-300">
              View Global Hazard Map
            </button>
          </div>
        </motion.div>
      </main>

      {/* Animated City Map Mockup */}
      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1/2 h-full opacity-30 pointer-events-none hidden lg:block">
        <CityMapAnimation />
      </div>
    </div>
  );
};

const StatCard = ({ icon, label, value }: { icon: React.ReactNode, label: string, value: string | number }) => (
  <motion.div 
    whileHover={{ y: -5, borderColor: 'rgba(16, 185, 129, 0.4)' }}
    className="p-6 rounded-2xl bg-zinc-900/50 border border-zinc-800 backdrop-blur-sm transition-colors"
  >
    <div className="flex items-center gap-3 mb-4">
      {icon}
      <span className="text-xs font-mono uppercase tracking-widest text-zinc-500">{label}</span>
    </div>
    <motion.div 
      key={value}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="text-4xl font-bold"
    >
      {value}
    </motion.div>
  </motion.div>
);

const CityMapAnimation = () => (
  <svg viewBox="0 0 800 800" className="w-full h-full">
    <defs>
      <radialGradient id="pulse" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#10b981" stopOpacity="0.4" />
        <stop offset="100%" stopColor="#10b981" stopOpacity="0" />
      </radialGradient>
    </defs>
    {/* Grid Lines */}
    {[...Array(20)].map((_, i) => (
      <line key={`h-${i}`} x1="0" y1={i * 40} x2="800" y2={i * 40} stroke="#333" strokeWidth="0.5" />
    ))}
    {[...Array(20)].map((_, i) => (
      <line key={`v-${i}`} x1={i * 40} y1="0" x2={i * 40} y2="800" stroke="#333" strokeWidth="0.5" />
    ))}
    
    {/* Pulse Points */}
    <motion.circle 
      cx="400" cy="400" r="100" fill="url(#pulse)"
      animate={{ scale: [1, 1.5, 1], opacity: [0.3, 0.6, 0.3] }}
      transition={{ duration: 4, repeat: Infinity }}
    />
    <motion.circle 
      cx="200" cy="300" r="60" fill="url(#pulse)"
      animate={{ scale: [1, 1.3, 1], opacity: [0.2, 0.5, 0.2] }}
      transition={{ duration: 3, repeat: Infinity, delay: 1 }}
    />
  </svg>
);
