import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Map as MapIcon, Shield, Users, Activity, AlertTriangle, Info, ArrowUpRight, RefreshCcw, ShieldAlert, X } from 'lucide-react';
import { useApp } from '../AppContext';
import { Zone, Shelter } from '../types';

export const Dashboard: React.FC = () => {
  const { zones, shelters, events, triggerAlert, updateShelter } = useApp();
  const [selectedShelter, setSelectedShelter] = useState<Shelter | null>(null);
  const [eventFilter, setEventFilter] = useState<string>('ALL');

  const filteredEvents = eventFilter === 'ALL' 
    ? events 
    : events.filter(e => e.type === eventFilter);

  return (
    <div className="flex-1 bg-[#0a0a0a] overflow-y-auto p-6 space-y-6">
      <header className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">RESPONDER COMMAND</h2>
          <p className="text-zinc-500 text-sm font-mono">OPERATIONAL VIEW // CITY_GRID_ALPHA</p>
        </div>
        <div className="flex gap-3">
          <button className="px-4 py-2 bg-zinc-900 border border-zinc-800 rounded-lg text-xs font-bold hover:bg-zinc-800 transition-colors flex items-center gap-2">
            <RefreshCcw size={14} /> RE-OPTIMIZE ROUTES
          </button>
          <button className="px-4 py-2 bg-red-600 text-white rounded-lg text-xs font-bold hover:bg-red-700 transition-colors flex items-center gap-2">
            <ShieldAlert size={14} /> BROADCAST EMERGENCY
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Map View */}
        <div className="lg:col-span-2 space-y-6">
          <div className="aspect-video bg-zinc-950 border border-zinc-800 rounded-2xl relative overflow-hidden group">
            <div className="absolute inset-0 opacity-40">
              <CityGridMap zones={zones} />
            </div>
            <div className="absolute top-4 left-4 p-3 bg-black/80 backdrop-blur-md border border-white/10 rounded-xl text-[10px] font-mono space-y-1 z-20">
              <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-red-500"></span> ACTIVE HAZARD</div>
              <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-amber-500"></span> ALERT ZONE</div>
              <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-emerald-500"></span> SAFE PASSAGE</div>
            </div>
            
            {/* Hazard Data Source UI */}
            <div className="absolute top-4 right-4 p-3 bg-black/80 backdrop-blur-md border border-white/10 rounded-xl z-20">
              <div className="flex items-center gap-3">
                <div className="flex flex-col">
                  <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-tighter">Data Source</span>
                  <span className="text-xs font-bold text-white flex items-center gap-1">
                    <Activity size={12} className="text-emerald-500" /> SAR Satellite: Sentinel-1
                  </span>
                </div>
                <div className="w-px h-8 bg-white/10"></div>
                <div className="flex flex-col">
                  <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-tighter">Latency</span>
                  <span className="text-xs font-bold text-emerald-400">142ms</span>
                </div>
              </div>
            </div>

            <div className="absolute bottom-4 right-4 text-[10px] font-mono text-zinc-500">
              SAR_SAT_SOURCE: SENTINEL-1 // LATENCY: 142ms
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-6">
              <h3 className="text-sm font-bold mb-4 flex items-center gap-2">
                <AlertTriangle size={16} className="text-amber-500" /> ACTIVE ZONES
              </h3>
              <div className="space-y-4">
                {zones.map(zone => (
                  <ZoneCard key={zone.id} zone={zone} onAlert={() => triggerAlert(zone.id, zone.status === 'Active' ? 'Normal' : 'Active')} />
                ))}
              </div>
            </div>
            <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-6">
              <h3 className="text-sm font-bold mb-4 flex items-center gap-2">
                <Shield size={16} className="text-emerald-500" /> SHELTER CAPACITY
              </h3>
              <div className="space-y-4">
                {shelters.map(shelter => (
                  <ShelterCard key={shelter.id} shelter={shelter} onClick={() => setSelectedShelter(shelter)} />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar Intel */}
        <div className="space-y-6">
          <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold flex items-center gap-2">
                <Activity size={16} className="text-blue-500" /> LIVE EVENT LOG
              </h3>
              <div className="flex gap-1">
                {['ALL', 'ALERT'].map(type => (
                  <button 
                    key={type}
                    onClick={() => setEventFilter(type)}
                    className={`text-[8px] font-bold px-2 py-1 rounded ${eventFilter === type ? 'bg-zinc-700 text-white' : 'text-zinc-500 hover:text-zinc-300'}`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-4 max-h-[400px] overflow-y-auto scrollbar-hide">
              <AnimatePresence mode="popLayout">
                {filteredEvents.map(event => (
                  <motion.div 
                    key={event.id} 
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="border-l-2 border-zinc-700 pl-4 py-1"
                  >
                    <div className="text-[10px] font-mono text-zinc-500 mb-1">{new Date(event.timestamp).toLocaleTimeString()}</div>
                    <div className="text-xs font-medium text-zinc-300">{event.message}</div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>

          <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-2xl p-6">
            <h3 className="text-sm font-bold mb-2 text-emerald-400">EVACUATION EFFICIENCY</h3>
            <div className="text-4xl font-bold mb-4">94.2%</div>
            <div className="w-full bg-zinc-800 h-2 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: '94.2%' }}
                className="h-full bg-emerald-500"
              />
            </div>
            <p className="text-[10px] text-zinc-500 mt-4 leading-relaxed">
              Current flow optimization is preventing gridlock at the Riverside North junction.
            </p>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {selectedShelter && (
          <ShelterUpdateModal 
            shelter={selectedShelter} 
            onClose={() => setSelectedShelter(null)} 
            onUpdate={async (status, occupied) => {
              await updateShelter(selectedShelter.id, status, occupied);
              setSelectedShelter(null);
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

const ZoneCard = ({ zone, onAlert }: { zone: Zone, onAlert: () => void }) => (
  <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-xl flex items-center justify-between group hover:border-zinc-700 transition-colors">
    <div>
      <div className="flex items-center gap-2 mb-1">
        <span className="text-xs font-bold">{zone.name}</span>
        <motion.span 
          animate={zone.status === 'Active' ? {
            backgroundColor: ['rgba(239, 68, 68, 0.2)', 'rgba(239, 68, 68, 0.4)', 'rgba(239, 68, 68, 0.2)'],
          } : zone.status === 'Alert' ? {
            backgroundColor: ['rgba(245, 158, 11, 0.2)', 'rgba(245, 158, 11, 0.4)', 'rgba(245, 158, 11, 0.2)'],
          } : {}}
          transition={{ duration: 2, repeat: Infinity }}
          className={`text-[8px] font-mono px-1.5 py-0.5 rounded ${
            zone.status === 'Active' ? 'text-red-500' : 
            zone.status === 'Alert' ? 'text-amber-500' : 
            'bg-emerald-500/20 text-emerald-500'
          }`}
        >
          {zone.status}
        </motion.span>
      </div>
      <div className="text-[10px] text-zinc-500">POP: {zone.population.toLocaleString()} // HAZARD: {(zone.hazard_level * 100).toFixed(0)}%</div>
    </div>
    <button 
      onClick={onAlert}
      className="p-2 bg-zinc-900 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity hover:bg-zinc-800"
    >
      <ArrowUpRight size={14} />
    </button>
  </div>
);

const ShelterCard = ({ shelter, onClick }: { shelter: Shelter, onClick: () => void }) => {
  const percent = (shelter.occupied / shelter.capacity) * 100;
  return (
    <div 
      onClick={onClick}
      className="p-4 bg-zinc-950 border border-zinc-800 rounded-xl cursor-pointer hover:border-zinc-600 transition-colors group"
    >
      <div className="flex justify-between items-center mb-2">
        <span className="text-xs font-bold group-hover:text-emerald-400 transition-colors">{shelter.name}</span>
        <span className="text-[10px] font-mono text-zinc-500">{shelter.occupied}/{shelter.capacity}</span>
      </div>
      <div className="w-full bg-zinc-900 h-1.5 rounded-full overflow-hidden">
        <div 
          className={`h-full transition-all duration-500 ${percent > 90 ? 'bg-red-500' : percent > 70 ? 'bg-amber-500' : 'bg-emerald-500'}`}
          style={{ width: `${percent}%` }}
        />
      </div>
    </div>
  );
};

const ShelterUpdateModal = ({ shelter, onClose, onUpdate }: { shelter: Shelter, onClose: () => void, onUpdate: (status: any, occupied: number) => void }) => {
  const [occupied, setOccupied] = useState(shelter.occupied);
  const [status, setStatus] = useState(shelter.status);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 w-full max-w-md shadow-2xl"
      >
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-bold">Update Shelter: {shelter.name}</h3>
          <button onClick={onClose} className="text-zinc-500 hover:text-white"><X size={20} /></button>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-[10px] font-mono text-zinc-500 uppercase mb-2">Occupancy Level</label>
            <input 
              type="range" 
              min="0" 
              max={shelter.capacity} 
              value={occupied} 
              onChange={(e) => setOccupied(parseInt(e.target.value))}
              className="w-full accent-emerald-500"
            />
            <div className="flex justify-between mt-2 text-xs font-mono">
              <span>{occupied}</span>
              <span className="text-zinc-500">CAP: {shelter.capacity}</span>
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-mono text-zinc-500 uppercase mb-2">Operational Status</label>
            <div className="grid grid-cols-3 gap-2">
              {['Open', 'Full', 'Closed'].map(s => (
                <button 
                  key={s}
                  onClick={() => setStatus(s as any)}
                  className={`py-2 rounded-lg text-xs font-bold border transition-all ${status === s ? 'bg-emerald-500 border-emerald-400 text-black' : 'bg-zinc-800 border-zinc-700 text-zinc-400 hover:border-zinc-500'}`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <button 
            onClick={() => onUpdate(status, occupied)}
            className="w-full py-3 bg-white text-black font-bold rounded-xl hover:bg-emerald-500 hover:text-white transition-all"
          >
            CONFIRM UPDATES
          </button>
        </div>
      </motion.div>
    </div>
  );
};

const CityGridMap = ({ zones }: { zones: Zone[] }) => (
  <svg viewBox="0 0 400 300" className="w-full h-full">
    {/* Mock City Blocks */}
    <rect x="20" y="20" width="80" height="60" fill={zones.find(z => z.id === 'Z1')?.status === 'Active' ? '#ef4444' : '#18181b'} stroke="#27272a" />
    <rect x="120" y="20" width="100" height="100" fill={zones.find(z => z.id === 'Z2')?.status === 'Active' ? '#ef4444' : '#18181b'} stroke="#27272a" />
    <rect x="240" y="20" width="140" height="80" fill={zones.find(z => z.id === 'Z3')?.status === 'Active' ? '#ef4444' : '#18181b'} stroke="#27272a" />
    <rect x="20" y="100" width="80" height="180" fill={zones.find(z => z.id === 'Z4')?.status === 'Active' ? '#ef4444' : '#18181b'} stroke="#27272a" />
    
    {/* Roads */}
    <line x1="110" y1="0" x2="110" y2="300" stroke="#3f3f46" strokeWidth="4" strokeDasharray="4 4" />
    <line x1="230" y1="0" x2="230" y2="300" stroke="#3f3f46" strokeWidth="4" strokeDasharray="4 4" />
    <line x1="0" y1="90" x2="400" y2="90" stroke="#3f3f46" strokeWidth="4" strokeDasharray="4 4" />
  </svg>
);


