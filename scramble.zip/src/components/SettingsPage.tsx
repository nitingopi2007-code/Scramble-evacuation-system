import React, { useState } from 'react';
import { motion } from 'motion/react';
import { User as UserIcon, Mail, Shield, Save, Camera, LogOut } from 'lucide-react';
import { useApp } from '../AppContext';

export const SettingsPage: React.FC = () => {
  const { user, updateUser } = useApp();
  const [formData, setFormData] = useState({ ...user });
  const [isSaving, setIsSaving] = useState(false);

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, avatar_url: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    await updateUser(formData);
    setIsSaving(false);
  };

  return (
    <div className="flex-1 bg-[#0a0a0a] overflow-y-auto p-6 space-y-8">
      <header>
        <h2 className="text-3xl font-bold tracking-tight">SYSTEM SETTINGS</h2>
        <p className="text-zinc-500 text-sm font-mono">USER PROFILE & PREFERENCES</p>
      </header>

      <div className="max-w-4xl grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Card */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-3xl p-8 flex flex-col items-center text-center">
            <div className="relative group mb-6">
              <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-emerald-500/20 group-hover:border-emerald-500 transition-all duration-500">
                <img src={formData.avatar_url} alt="Avatar" className="w-full h-full object-cover" />
              </div>
              <label className="absolute bottom-0 right-0 p-2 bg-emerald-500 text-black rounded-full cursor-pointer hover:scale-110 transition-transform shadow-lg">
                <input type="file" className="hidden" onChange={handleAvatarUpload} accept="image/*" />
                <Camera size={16} />
              </label>
            </div>
            <h3 className="text-xl font-bold mb-1">{user.name}</h3>
            <p className="text-zinc-500 text-sm font-mono uppercase tracking-widest mb-6">{user.role}</p>
            <div className="w-full pt-6 border-t border-zinc-800 flex flex-col gap-3">
              <div className="flex items-center gap-3 text-sm text-zinc-400">
                <Mail size={16} /> {user.email}
              </div>
              <div className="flex items-center gap-3 text-sm text-zinc-400">
                <Shield size={16} /> Access Level: Level 4
              </div>
            </div>
          </div>

          <button className="w-full py-4 bg-zinc-900 text-red-500 font-bold rounded-2xl border border-zinc-800 hover:bg-red-500/10 transition-all flex items-center justify-center gap-2">
            <LogOut size={18} /> LOGOUT SESSION
          </button>
        </div>

        {/* Edit Form */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-3xl p-8 space-y-8">
            <h4 className="text-sm font-bold uppercase tracking-widest text-zinc-500">Account Information</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-mono text-zinc-500 uppercase">Full Name</label>
                <div className="relative">
                  <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
                  <input 
                    type="text" 
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full bg-zinc-800 border border-zinc-700 rounded-xl py-3 pl-12 pr-4 text-sm focus:outline-none focus:border-emerald-500 transition-colors"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-mono text-zinc-500 uppercase">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
                  <input 
                    type="email" 
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full bg-zinc-800 border border-zinc-700 rounded-xl py-3 pl-12 pr-4 text-sm focus:outline-none focus:border-emerald-500 transition-colors"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-mono text-zinc-500 uppercase">Operational Role</label>
                <div className="relative">
                  <Shield className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
                  <select 
                    value={formData.role}
                    onChange={(e) => setFormData(prev => ({ ...prev, role: e.target.value }))}
                    className="w-full bg-zinc-800 border border-zinc-700 rounded-xl py-3 pl-12 pr-4 text-sm focus:outline-none focus:border-emerald-500 transition-colors appearance-none"
                  >
                    <option>Commander</option>
                    <option>Field Agent</option>
                    <option>Logistics Coordinator</option>
                    <option>Medical Liaison</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="pt-8 border-t border-zinc-800">
              <button 
                onClick={handleSave}
                disabled={isSaving}
                className="px-8 py-4 bg-emerald-500 text-black font-bold rounded-xl hover:bg-emerald-400 transition-all flex items-center gap-2 disabled:opacity-50"
              >
                <Save size={18} /> {isSaving ? 'SAVING CHANGES...' : 'SAVE PROFILE'}
              </button>
            </div>
          </div>

          <div className="bg-emerald-500/5 border border-emerald-500/10 rounded-3xl p-8">
            <h4 className="text-sm font-bold text-emerald-500 mb-2">SECURITY NOTICE</h4>
            <p className="text-xs text-zinc-500 leading-relaxed">
              Your account is currently operating under high-security protocols. All profile changes are logged and audited by the SCRAMBLE central command.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
