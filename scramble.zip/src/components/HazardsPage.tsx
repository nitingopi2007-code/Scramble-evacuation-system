import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, Camera, Upload, MapPin, Clock, ShieldAlert, X } from 'lucide-react';
import { useApp } from '../AppContext';

export const HazardsPage: React.FC = () => {
  const { hazardReports, zones, user, reportHazard } = useApp();
  const [isReporting, setIsReporting] = useState(false);
  const [newReport, setNewReport] = useState({
    zone_id: 'Z1',
    type: 'Flood',
    description: '',
    image_url: ''
  });

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewReport(prev => ({ ...prev, image_url: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async () => {
    await reportHazard({
      ...newReport,
      reporter_id: user.id
    });
    setIsReporting(false);
    setNewReport({ zone_id: 'Z1', type: 'Flood', description: '', image_url: '' });
  };

  return (
    <div className="flex-1 bg-[#0a0a0a] overflow-y-auto p-6 space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">HAZARD INTELLIGENCE</h2>
          <p className="text-zinc-500 text-sm font-mono">CROWD-SOURCED & SENSOR DATA</p>
        </div>
        <button 
          onClick={() => setIsReporting(true)}
          className="px-6 py-3 bg-emerald-500 text-black font-bold rounded-xl hover:bg-emerald-400 transition-all flex items-center gap-2"
        >
          <ShieldAlert size={18} /> REPORT HAZARD
        </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence mode="popLayout">
          {hazardReports.map((report) => (
            <motion.div 
              key={report.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-zinc-900/50 border border-zinc-800 rounded-2xl overflow-hidden group hover:border-zinc-700 transition-all"
            >
              {report.image_url && (
                <div className="aspect-video w-full overflow-hidden">
                  <img src={report.image_url} alt="Hazard" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
              )}
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="px-2 py-1 bg-red-500/20 text-red-500 text-[10px] font-bold rounded uppercase tracking-widest">
                    {report.type}
                  </span>
                  <div className="flex items-center gap-1 text-[10px] text-zinc-500 font-mono">
                    <Clock size={12} /> {new Date(report.timestamp).toLocaleTimeString()}
                  </div>
                </div>
                <h3 className="font-bold mb-2 flex items-center gap-2">
                  <MapPin size={16} className="text-zinc-500" /> {zones.find(z => z.id === report.zone_id)?.name || report.zone_id}
                </h3>
                <p className="text-sm text-zinc-400 leading-relaxed">
                  {report.description}
                </p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {isReporting && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-zinc-900 border border-zinc-800 rounded-2xl p-8 w-full max-w-xl shadow-2xl"
            >
              <div className="flex justify-between items-center mb-8">
                <h3 className="text-2xl font-bold">Report New Hazard</h3>
                <button onClick={() => setIsReporting(false)} className="text-zinc-500 hover:text-white"><X size={24} /></button>
              </div>

              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-mono text-zinc-500 uppercase mb-2">Hazard Type</label>
                    <select 
                      value={newReport.type}
                      onChange={(e) => setNewReport(prev => ({ ...prev, type: e.target.value }))}
                      className="w-full bg-zinc-800 border border-zinc-700 rounded-xl p-3 text-sm focus:outline-none focus:border-emerald-500"
                    >
                      <option>Flood</option>
                      <option>Fire</option>
                      <option>Structural Damage</option>
                      <option>Road Block</option>
                      <option>Medical Emergency</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono text-zinc-500 uppercase mb-2">Location Zone</label>
                    <select 
                      value={newReport.zone_id}
                      onChange={(e) => setNewReport(prev => ({ ...prev, zone_id: e.target.value }))}
                      className="w-full bg-zinc-800 border border-zinc-700 rounded-xl p-3 text-sm focus:outline-none focus:border-emerald-500"
                    >
                      {zones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-mono text-zinc-500 uppercase mb-2">Description</label>
                  <textarea 
                    value={newReport.description}
                    onChange={(e) => setNewReport(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Describe the hazard in detail..."
                    className="w-full bg-zinc-800 border border-zinc-700 rounded-xl p-4 text-sm h-32 resize-none focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-mono text-zinc-500 uppercase mb-2">Evidence (Photo)</label>
                  <div className="flex gap-4">
                    <label className="flex-1 flex flex-col items-center justify-center border-2 border-dashed border-zinc-700 rounded-xl p-6 hover:border-emerald-500 transition-colors cursor-pointer group">
                      <input type="file" className="hidden" onChange={handleFileUpload} accept="image/*" />
                      {newReport.image_url ? (
                        <img src={newReport.image_url} alt="Preview" className="h-24 rounded-lg" />
                      ) : (
                        <>
                          <Camera className="text-zinc-500 group-hover:text-emerald-500 mb-2" size={32} />
                          <span className="text-xs text-zinc-500">Click to upload image</span>
                        </>
                      )}
                    </label>
                  </div>
                </div>

                <button 
                  onClick={handleSubmit}
                  className="w-full py-4 bg-emerald-500 text-black font-bold rounded-xl hover:bg-emerald-400 transition-all flex items-center justify-center gap-2"
                >
                  <Upload size={18} /> SUBMIT REPORT
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
