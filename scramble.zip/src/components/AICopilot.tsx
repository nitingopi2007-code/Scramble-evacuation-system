import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Bot, User, ShieldAlert, Loader2, RefreshCcw } from 'lucide-react';
import Markdown from 'react-markdown';
import { GoogleGenAI } from '@google/genai';
import { useApp } from '../AppContext';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export const AICopilot: React.FC = () => {
  const { zones, shelters, triggerAlert, updateShelter } = useApp();
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'SCRAMBLE Co-pilot active. How can I assist with the current evacuation state?' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const model = ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          { role: 'user', parts: [{ text: userMessage }] }
        ],
        config: {
          systemInstruction: `
            You are the SCRAMBLE AI Co-pilot.
            Current System State:
            Zones: ${JSON.stringify(zones)}
            Shelters: ${JSON.stringify(shelters)}

            Capabilities:
            - Answer questions about evacuation status.
            - Suggest route optimizations.
            - Explain hazard detection (Sentinel-1 SAR).
            - Generate instructions in Kannada, Hindi, Tamil, Telugu, English.

            If the user asks to "alert" a zone or "update" a shelter, tell them you can prepare the command but they must confirm it in the dashboard.
            Be concise, technical, and serious.
          `
        }
      });

      const result = await model;
      setMessages(prev => [...prev, { role: 'assistant', content: result.text || "I couldn't process that request." }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'assistant', content: "Error connecting to intelligence layer." }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-zinc-950 border-l border-zinc-800 w-96">
      <div className="p-4 border-bottom border-zinc-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bot className="text-emerald-500" size={20} />
          <span className="font-bold text-sm tracking-tight">AI CO-PILOT</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="text-[10px] font-mono text-zinc-500 uppercase">Live Intel</span>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] p-3 rounded-2xl text-sm ${
              msg.role === 'user' 
                ? 'bg-emerald-600 text-white' 
                : 'bg-zinc-900 text-zinc-300 border border-zinc-800'
            }`}>
              <div className="markdown-body">
                <Markdown>{msg.content}</Markdown>
              </div>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-zinc-900 p-3 rounded-2xl border border-zinc-800">
              <Loader2 className="animate-spin text-zinc-500" size={16} />
            </div>
          </div>
        )}
      </div>

      <div className="p-4 border-t border-zinc-800">
        <div className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask co-pilot..."
            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-3 pl-4 pr-12 text-sm focus:outline-none focus:border-emerald-500 transition-colors"
          />
          <button 
            onClick={handleSend}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-zinc-500 hover:text-emerald-500 transition-colors"
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};
