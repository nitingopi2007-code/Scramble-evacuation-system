import React, { createContext, useContext, useEffect, useState } from 'react';
import { io, Socket } from 'socket.io-client';
import { AppState, Zone, Shelter, User, HazardReport } from './types';

interface AppContextType extends AppState {
  updateShelter: (id: string, status: string, occupied: number) => Promise<void>;
  triggerAlert: (zoneId: string, status: string) => Promise<void>;
  updateUser: (userData: User) => Promise<void>;
  reportHazard: (report: Omit<HazardReport, 'id' | 'timestamp'>) => Promise<void>;
  loading: boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AppState>({
    zones: [],
    shelters: [],
    events: [],
    user: { id: '', name: '', email: '', role: '', avatar_url: '' },
    hazardReports: [],
  });
  const [loading, setLoading] = useState(true);
  const [socket, setSocket] = useState<Socket | null>(null);

  const fetchState = async () => {
    const res = await fetch('/api/state');
    const data = await res.json();
    setState(data);
    setLoading(false);
  };

  useEffect(() => {
    const newSocket = io();
    setSocket(newSocket);

    fetchState();

    newSocket.on('state-update', (update) => {
      if (update.type === 'hazard-report') {
        fetchState();
        return;
      }
      setState(prev => {
        if (update.type === 'zone') {
          return {
            ...prev,
            zones: prev.zones.map(z => z.id === update.id ? { ...z, status: update.status } : z)
          };
        }
        if (update.type === 'shelter') {
          return {
            ...prev,
            shelters: prev.shelters.map(s => s.id === update.id ? { ...s, status: update.status, occupied: update.occupied } : s)
          };
        }
        return prev;
      });
    });

    return () => {
      newSocket.close();
    };
  }, []);

  const updateShelter = async (id: string, status: string, occupied: number) => {
    await fetch('/api/update-shelter', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, status, occupied }),
    });
  };

  const triggerAlert = async (zoneId: string, status: string) => {
    await fetch('/api/trigger-alert', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ zoneId, status }),
    });
  };

  const updateUser = async (userData: User) => {
    await fetch('/api/update-user', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData),
    });
    setState(prev => ({ ...prev, user: userData }));
  };

  const reportHazard = async (report: Omit<HazardReport, 'id' | 'timestamp'>) => {
    await fetch('/api/report-hazard', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(report),
    });
  };

  return (
    <AppContext.Provider value={{ ...state, updateShelter, triggerAlert, updateUser, reportHazard, loading }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
