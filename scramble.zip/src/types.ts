export interface Zone {
  id: string;
  name: string;
  status: 'Normal' | 'Alert' | 'Active';
  population: number;
  evacuated: number;
  hazard_level: number;
}

export interface Shelter {
  id: string;
  name: string;
  capacity: number;
  occupied: number;
  status: 'Open' | 'Full' | 'Closed';
}

export interface EmergencyEvent {
  id: number;
  type: string;
  message: string;
  timestamp: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  avatar_url: string;
}

export interface HazardReport {
  id: number;
  zone_id: string;
  reporter_id: string;
  type: string;
  description: string;
  image_url: string;
  timestamp: string;
}

export interface AppState {
  zones: Zone[];
  shelters: Shelter[];
  events: EmergencyEvent[];
  user: User;
  hazardReports: HazardReport[];
}
