import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("scramble.db");

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS zones (
    id TEXT PRIMARY KEY,
    name TEXT,
    status TEXT, -- 'Normal', 'Alert', 'Active'
    population INTEGER,
    evacuated INTEGER DEFAULT 0,
    hazard_level REAL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS shelters (
    id TEXT PRIMARY KEY,
    name TEXT,
    capacity INTEGER,
    occupied INTEGER DEFAULT 0,
    status TEXT -- 'Open', 'Full', 'Closed'
  );

  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT,
    message TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT,
    email TEXT,
    role TEXT,
    avatar_url TEXT
  );

  CREATE TABLE IF NOT EXISTS hazard_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    zone_id TEXT,
    reporter_id TEXT,
    type TEXT, -- 'Flood', 'Fire', 'Structural', etc.
    description TEXT,
    image_url TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

// Seed data if empty
const zoneCount = db.prepare("SELECT COUNT(*) as count FROM zones").get() as { count: number };
if (zoneCount.count === 0) {
  const insertZone = db.prepare("INSERT INTO zones (id, name, status, population, hazard_level) VALUES (?, ?, ?, ?, ?)");
  insertZone.run("Z1", "Downtown Core", "Normal", 15000, 0.1);
  insertZone.run("Z2", "Riverside North", "Alert", 8000, 0.4);
  insertZone.run("Z3", "Industrial East", "Normal", 5000, 0.0);
  insertZone.run("Z4", "Residential West", "Active", 12000, 0.8);

  const insertShelter = db.prepare("INSERT INTO shelters (id, name, capacity, occupied, status) VALUES (?, ?, ?, ?, ?)");
  insertShelter.run("S1", "Central Stadium", 5000, 1200, "Open");
  insertShelter.run("S2", "North High School", 2000, 1800, "Open");
  insertShelter.run("S3", "East Community Center", 1500, 1500, "Full");

  const insertUser = db.prepare("INSERT INTO users (id, name, email, role, avatar_url) VALUES (?, ?, ?, ?, ?)");
  insertUser.run("U1", "Admin User", "admin@scramble.city", "Commander", "https://picsum.photos/seed/admin/200");
}

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer);
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // API Routes
  app.get("/api/state", (req, res) => {
    const zones = db.prepare("SELECT * FROM zones").all();
    const shelters = db.prepare("SELECT * FROM shelters").all();
    const events = db.prepare("SELECT * FROM events ORDER BY timestamp DESC LIMIT 10").all();
    const user = db.prepare("SELECT * FROM users LIMIT 1").get();
    const hazardReports = db.prepare("SELECT * FROM hazard_reports ORDER BY timestamp DESC").all();
    res.json({ zones, shelters, events, user, hazardReports });
  });

  app.post("/api/update-user", (req, res) => {
    const { id, name, email, role, avatar_url } = req.body;
    db.prepare("UPDATE users SET name = ?, email = ?, role = ?, avatar_url = ? WHERE id = ?").run(name, email, role, avatar_url, id);
    res.json({ success: true });
  });

  app.post("/api/report-hazard", (req, res) => {
    const { zone_id, reporter_id, type, description, image_url } = req.body;
    db.prepare("INSERT INTO hazard_reports (zone_id, reporter_id, type, description, image_url) VALUES (?, ?, ?, ?, ?)").run(zone_id, reporter_id, type, description, image_url);
    db.prepare("INSERT INTO events (type, message) VALUES (?, ?)").run("HAZARD", `New ${type} report in ${zone_id}`);
    io.emit("state-update", { type: "hazard-report" });
    res.json({ success: true });
  });

  app.post("/api/update-shelter", (req, res) => {
    const { id, status, occupied } = req.body;
    db.prepare("UPDATE shelters SET status = ?, occupied = ? WHERE id = ?").run(status, occupied, id);
    io.emit("state-update", { type: "shelter", id, status, occupied });
    res.json({ success: true });
  });

  app.post("/api/trigger-alert", (req, res) => {
    const { zoneId, status } = req.body;
    db.prepare("UPDATE zones SET status = ? WHERE id = ?").run(status, zoneId);
    db.prepare("INSERT INTO events (type, message) VALUES (?, ?)").run("ALERT", `Zone ${zoneId} status changed to ${status}`);
    io.emit("state-update", { type: "zone", id: zoneId, status });
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  io.on("connection", (socket) => {
    console.log("Client connected");
    socket.emit("initial-state", {
      zones: db.prepare("SELECT * FROM zones").all(),
      shelters: db.prepare("SELECT * FROM shelters").all(),
    });
  });

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`SCRAMBLE Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
